var CelsiusToFahreneit = function (x) {
    console.log(x * 9 / 5 + 32);
};
CelsiusToFahreneit(33);
