"use strict";
exports.__esModule = true;
function largestAmongTheeNum(a, b, c) {
    a = Math.max(a, b, c);
    //console.log(a);
    return a;
}
//largestAmongTheeNum(1,2,3);
exports["default"] = largestAmongTheeNum;
