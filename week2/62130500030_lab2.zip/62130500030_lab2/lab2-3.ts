import {largestAmongTheeNum} from "./lab2-2.js";

console.log(largestAmongTheeNum(1,2,3));