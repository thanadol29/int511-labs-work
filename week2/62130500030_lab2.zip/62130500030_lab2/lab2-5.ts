import largestAmongTheeNum from "./lab2-4";
console.log(largestAmongTheeNum(2,4,6));