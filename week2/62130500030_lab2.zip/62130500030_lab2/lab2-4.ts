function largestAmongTheeNum (a : number,b: number,c:number){
    a = Math.max(a,b,c);
    //console.log(a);
    return a;
}
//largestAmongTheeNum(1,2,3);

export default largestAmongTheeNum;