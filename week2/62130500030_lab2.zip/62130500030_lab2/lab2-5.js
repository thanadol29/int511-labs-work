"use strict";
exports.__esModule = true;
var lab2_4_1 = require("./lab2-4");
console.log((0, lab2_4_1["default"])(2, 4, 6));
