"use strict";
exports.__esModule = true;
var lab2_6_1 = require("./lab2-6");
console.log((0, lab2_6_1.lastAmongTheeNum)(55, 53, 235));
