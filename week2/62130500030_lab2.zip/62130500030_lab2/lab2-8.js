"use strict";
exports.__esModule = true;
var mylib = require("./lab2-6");
console.log(mylib.lastAmongTheeNum(213, 41234, 12));
console.log(mylib.removeItemFromArray([1, 2, 3, 4, 5], 3));
