import {lastAmongTheeNum} from "./lab2-6";
console.log(lastAmongTheeNum(55,53,235));