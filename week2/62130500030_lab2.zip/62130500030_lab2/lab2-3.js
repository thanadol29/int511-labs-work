"use strict";
exports.__esModule = true;
var lab2_2_ts_1 = require("./lab2-2.ts");
console.log((0, lab2_2_ts_1["default"])(1, 2, 3));
