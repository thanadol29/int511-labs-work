var CelsiusToFahreneit = (x : number) => {  
    console.log(x * 9/5 +32)
};
CelsiusToFahreneit(33);
